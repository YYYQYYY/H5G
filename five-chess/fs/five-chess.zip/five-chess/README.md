#简介
NodeJS + Socket.io开发的网络版五子棋，类似QQ游戏的五子棋，有大厅、用户列表、房间、聊天等功能。   

#安装
1、下载源代码，安装socket.io   
2、运行服务端， 进入server目录，执行node index.js   
3、使用http server(nginx或apache)将目录指向client目录（需要访问图片，html等文件)    
4、修改服务器IP和端口(分别位于index.html第70，87，88行)   
5、访问index.html即可

#图片
![image](http://static.oschina.net/uploads/space/2014/1211/112829_yV8j_140911.png) 
![image](http://static.oschina.net/uploads/space/2014/1211/113039_6wba_140911.jpg)  